package com.compuni;

public interface Comparatore {
    public int confrontaCon(Object o1, Object o2);
}
