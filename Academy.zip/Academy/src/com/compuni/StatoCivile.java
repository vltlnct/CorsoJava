package com.compuni;

public class StatoCivile {

}
