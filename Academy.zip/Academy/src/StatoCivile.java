public class StatoCivile {


}
