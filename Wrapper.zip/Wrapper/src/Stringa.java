public class Stringa {
            public int lunghezza=0;
            private char[] str;
            public int larghezza;


            // Costruttore
            public Stringa(char[] strInput) {
                int i;
                char[] tempo = new char[strInput.length];
                for (i=0; i<strInput.length; i++) {
                    tempo[i] = strInput[i];
                }
                this.lunghezza = strInput.length;
                System.out.println("Lunghezza ="+this.lunghezza);
                this.str = tempo;
            }


            public Stringa(int length, char[] str) {
                this.lunghezza = length;
                this.str = str; //Passaggio per riferimento
            }


            public char[] toUpperCase(){
            //....
            for (int i=0; i<this.lunghezza; i++) {
                if ( (this.str[i] >=97) && (this.str[i] <= 122) ){
                    this.str[i] = (char) (this.str[i] - 32);
                }
            }
            return this.str;
        }

        public String concat(String str)
        {
            return str;
        }

        public int length()
        {
            return this.lunghezza;
        }

        public static void ciao(){
                System.out.println("Ciao dalla classe Stringa");
        }


}


