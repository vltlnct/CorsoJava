public class NuovaStringa {
}
