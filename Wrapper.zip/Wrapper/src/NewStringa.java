public class NewStringa extends Stringa {


    public NewStringa(char[] strInput, int lunghezza) {
        super(strInput);
        lunghezza = lunghezza;
        //this.str = str; //Passaggio per riferimento
    }
}
